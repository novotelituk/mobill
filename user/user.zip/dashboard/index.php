<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require_once('../../settings/db.php');
$id=$_GET['id'];
$site="http://localhost";
$url=$_SERVER['REQUEST_URI'];
$uniurl=$site.$url;
if(isset($_SESSION['fbid']))
{
	$admlog=1;
	//$sql=mysql_query("UPDATE `track` SET `url`='$uniurl' WHERE `fbid`='$id'") or die("Error");
	echo "<a href='admin.php'>Admin</a>";
}

?>